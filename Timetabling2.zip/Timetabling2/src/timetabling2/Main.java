package timetabling2;
import java.util.Scanner;
import java.io.IOException;

public class Main {
	
	static final String direktori = "D:/Kuliah PAHMI/Semester 6/OKH/FP/Toronto/"; //Jangan lupa untuk mengubah direktori :))
        static String[][] namaFile = {
                                    {"car-f-92", "CAR92"}, 
                                    {"car-s-91", "CAR91"}, 
                                    {"ear-f-83", "EAR83"}, 
                                    {"hec-s-92", "HEC92"},
                                    {"kfu-s-93", "KFU93"}, 
                                    {"lse-f-91", "LSE91"}, 
                                    {"pur-s-93", "PUR93"}, 
                                    {"rye-s-93", "RYE93"}, 
                                    {"sta-f-83", "STA83"},
                                    {"tre-s-92", "TRE92"},	
                                    {"uta-s-92", "UTA92"}, 
                                    {"ute-s-92", "UTE92"}, 
                                    {"yor-f-83", "YOR83"}};
        static int timeslot[]; 
        static int[][] conflictMatrix, courseSorted, timeslotResult;
	
	public static void main(String[] args) throws IOException {
		
		for(int i=0; i< namaFile.length; i++)
        	System.out.println(i+1 + ". Penjadwalan " + namaFile[i][1]);
                
		System.out.print("\nData set yang akan dijadwalkan : ");
		Scanner input = new Scanner(System.in);
		int dataset = input.nextInt();
                
                String fileInput = namaFile[dataset-1][0];
                String fileOutput = namaFile[dataset-1][1];
        
            String file = direktori + fileInput;
        	
            Course course = new Course(file);
            int totalExam = course.getNumberOfCourses();
        
            conflictMatrix = course.getConflictMatrix();
            int totalMurid = course.getTotalMurid();
		
            //Exam
            courseSorted = course.sortingByDegree(conflictMatrix, totalExam);
            
            //Penjadwalan
            long starttimeLD = System.nanoTime(); //menghitung time execution
            Schedule schedule = new Schedule(file, conflictMatrix, totalExam);
            timeslot = schedule.schedulingByDegree(courseSorted);
            int[][] timeslotLD = schedule.getSchedule();
            long endtimeLD = System.nanoTime();	//menghitung time execution
            
            //Result
            System.out.println("\n================================================\n");
            System.out.println("Penjadwalan " + fileOutput );
            System.out.println("Timeslots  	: " + schedule.getTotalTimeslots(schedule.getSchedule()));
            System.out.println("Penalty  	: " + Evaluator.getPenalty(conflictMatrix, schedule.getSchedule(), totalMurid));
            System.out.println("Time Execution  : " + ((double) (endtimeLD - starttimeLD)/1000000000) + " detik.\n");
	}
}
